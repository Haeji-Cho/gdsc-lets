package com.example.gdsc_lets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class KeepActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keep);
    }
}