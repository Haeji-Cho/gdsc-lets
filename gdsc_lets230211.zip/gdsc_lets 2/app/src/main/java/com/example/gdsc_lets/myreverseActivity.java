package com.example.gdsc_lets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class myreverseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myreverse);
    }
}